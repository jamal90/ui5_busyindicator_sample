sap.ui.define([
	"sap/ui/base/Object"
], function(Object) {
	"use strict";
	
	return Object.extend("com.jam.portal.headerportalHeader.util.BusyIndicatorLoader", {

		performAfterLoadingBusyState: function(callback, args, listener){
			setTimeout(function(){
				callback.apply(listener, args);                         
			}, 0);	
		} ,
		
		setBusyStateWithNotifier: function(dialog){
			dialog.open();
			var deferred = jQuery.Deferred();
			
			// setting & holding the busy indicator as long as some backend process is happening
			var processCounter = 0; 
			$.when(deferred).progress(function(type){
				if (type === "START"){
					processCounter++;
				}else if (type === "END"){
					processCounter--;
					if (processCounter === 0){
						deferred.resolve();
					}
				}
			});
			
			// releasing the busy indicator
			$.when(deferred).done(function(){
				dialog.close();	
			});
			
			return deferred;
		}	
	});

});