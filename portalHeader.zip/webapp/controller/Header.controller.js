sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/jam/portal/headerportalHeader/util/BusyIndicatorLoader"
], function(Controller, BusyIndicatorLoader) {
	"use strict";

	return Controller.extend("com.jam.portal.headerportalHeader.controller.Header", {
		onInit: function(oEvt){
			this.oEventBus = sap.ui.getCore().getEventBus();
			this._oDialog = this.getView().byId("BusyDialog");
			this._busyIndicatorLoader = new BusyIndicatorLoader();
			
			// register for events from other components
			this.oEventBus.subscribe("portal-channel", "eventFromSection1", this.handleEventFromSection1, this);
		},
		
		// recommended implementation

		doCountryChange: function(oNotifier){
			// publish events to all channels
			this.oEventBus.publish("portal-channel", "countryChange", {
				notifier: oNotifier
				// other params to be included as required
			});
		},
		
		handleCountryChange: function(oEvt){
			// oEvt.getSource().getCustomDat()['country']
			var busyStateNotifier = this._busyIndicatorLoader.setBusyStateWithNotifier(this._oDialog);
			this._busyIndicatorLoader.performAfterLoadingBusyState(this.doCountryChange, [busyStateNotifier], this);
		},
		
		// implementation - as is
		/*handleCountryChange: function(oEvt){
			
			this._oDialog.open();
			
			setTimeout(jQuery.proxy(function(){
				this.doCountryChange();
			}, this), 0);
			
			setTimeout(jQuery.proxy(function(){
				this._oDialog.close();
			},this), 0);

		}*/
		
		
		// ===========
		
		handleEventFromSection1: function(sChannelName, sEventId, oParams){
			oParams.notifier.notify("START");
			
			// load some data
			$.ajax({
				url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(), 
				type: "GET", 
				success: function(data, status){

					$.ajax({
						url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
						type: "GET", 
						success: function(data2, status2){
							
							$.ajax({
								url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
								type: "GET", 
								success: function(data3, status3){
									$.ajax({
										url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
										type: "GET", 
										success: function(data4, status4){
											jQuery.sap.log.info("DONE ALL CALLS");
											oParams.notifier.notify("END");
										}, 
										error: function(err){
											jQuery.sap.log.error("ERROR");
										}
									});

								}, 
								error: function(err){
									jQuery.sap.log.error("ERROR");									
								}
							});
							
						}, 
						error: function(err){
							jQuery.sap.log.error("ERROR");							
						}
					});
				}, 
				error: function(err){
					jQuery.sap.log.error("ERROR");							
				}
			});
			
		}
		
		
		
	});
});