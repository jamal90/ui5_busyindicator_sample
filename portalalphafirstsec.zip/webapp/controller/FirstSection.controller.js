sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/jam/portal/headerportalHeader/util/BusyIndicatorLoader"
], function(Controller, JSONModel, BusyIndicatorLoader) {
	"use strict";

	return Controller.extend("portalalphafirstsec.controller.FirstSection", {
		
		onInit: function(){
			this.oViewModel =  new JSONModel();
			this.getView().setModel(this.oViewModel);
			
			this._oDialog = this.getView().byId("BusyDialog");
			this._busyIndicatorLoader = new BusyIndicatorLoader();
			this.oEventBus = sap.ui.getCore().getEventBus();
			this.oEventBus.subscribe("portal-channel", "countryChange", this.handleCountryChange, this);
			var that = this; 
			
			// load the initial data
			$.ajax({
				url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Customers?$format=json", // &$filter=Country eq 'Germany' 
				type: "GET", 
				success: function(data, status){
					that.oViewModel.setData({"Customers" : data.d.results});
				}, 
				error: function(err){
					
				}
			});	
			
			// subscribe to the event
			
		},
		
		doSomeFunc: function(oNotifier){
			// publish events to all channels
			this.oEventBus.publish("portal-channel", "eventFromSection1", {
				notifier: oNotifier
				// other params to be included as required
			});
		},
		
		handleButtonPress: function(oEvt){
			var busyStateNotifier = this._busyIndicatorLoader.setBusyStateWithNotifier(this._oDialog);
			this._busyIndicatorLoader.performAfterLoadingBusyState(this.doSomeFunc, [busyStateNotifier], this);
		},
		
		handleCountryChange: function(sChannelName, sEventId, oParams){
			
			var that = this; 
			oParams.notifier.notify("START");
			
			// load some data
			$.ajax({
				url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(), 
				type: "GET", 
				success: function(data, status){

					$.ajax({
						url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
						type: "GET", 
						success: function(data2, status2){
							
							$.ajax({
								url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
								type: "GET", 
								success: function(data3, status3){
									$.ajax({
										url: "/sap/fiori/portalalphafirstsec/north_wind_service/v2/Northwind/Northwind.svc/Invoices?$format=json&_="+Math.random(),
										type: "GET", 
										success: function(data4, status4){
											jQuery.sap.log.info("DONE ALL CALLS");
											oParams.notifier.notify("END");
										}, 
										error: function(err){
											jQuery.sap.log.error("ERROR");
										}
									});

								}, 
								error: function(err){
									jQuery.sap.log.error("ERROR");									
								}
							});
							
						}, 
						error: function(err){
							jQuery.sap.log.error("ERROR");							
						}
					});
				}, 
				error: function(err){
					jQuery.sap.log.error("ERROR");							
				}
			});
		}
	});
});